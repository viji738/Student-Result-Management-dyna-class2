<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Result Management System</title>

    <!-- CSS Dependencies -->
    <link rel="stylesheet" href="css/bootstrap.min.css" media="screen">
    <link rel="stylesheet" href="css/font-awesome.min.css" media="screen">
    <link rel="stylesheet" href="css/animate-css/animate.min.css" media="screen">
    <link rel="stylesheet" href="css/icheck/skins/flat/blue.css">
    <link rel="stylesheet" href="css/main.css" media="screen">

    <!-- Google Font for Calligraphy -->
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">

    <script src="js/modernizr/modernizr.min.js"></script>

    <style>
        .login-bg-color {
    position: relative;       /* Add relative positioning */
    height: 100vh;
    width: 100%;
    background: url('images/Screenshot 2025-05-25 234359.png') no-repeat center center fixed;
    background-size: cover;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    overflow: hidden;
}

/* Add a dimming overlay inside .login-bg-color */
.login-bg-color::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background-color: rgba(0, 0, 0, 0.5); /* Change opacity here */
    z-index: 0;
}

.col-md-4 {
    position: relative;
    z-index: 1;
}
        .dynaclass {
    position: relative;    /* Make z-index work */
    z-index: 1;            /* Above overlay */
    font-family: 'Dancing Script', cursive;
    font-size: 50px;
    text-align: center;
    margin-bottom: 0;
    color: #fff;
    text-shadow: 1px 1px 3px #000;
}


.panel {
    background-color: rgba(255, 255, 255, 0.95);
    border-radius: 10px;
    margin-top: 0;
}

        .form-heading {
            text-align: center;
            font-weight: bold;
            margin-bottom: 15px;
            font-size: 20px;
        }

       .footer {
    position: relative;   /* Enable z-index */
    z-index: 1;           /* Above overlay */
    margin-top: 20px;
    text-align: center;
    font-size: 16px;
    font-family: 'Dancing Script', cursive;
    color: #fff;
    background-color: rgba(0, 0, 0, 0.3);
    padding: 10px 20px;
    border-radius: 8px;
}


        .btn-inline-group {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn-inline-group a {
            padding-left: 10px;
            font-size: 14px;
            color: #337ab7;
        }

        .btn-inline-group a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="main-wrapper">
        <div class="login-bg-color">
            <!-- DynaClass heading outside the panel and form -->
            <div class="dynaclass">DynaClass</div>

            <div class="col-md-4 col-md-offset-0">
                <div class="panel login-box">
                    <div class="panel-body p-20">

                        <form action="result.php" method="post">
                            <div class="form-heading">View Results</div>

                            <div class="form-group">
                                <label for="rollid">Enter your Roll Id</label>
                                <input type="text" class="form-control" id="rollid" placeholder="Enter Your Roll Id" autocomplete="off" name="rollid">
                            </div>

                            <div class="form-group">
                                <label for="default" class="col-sm-2 control-label">Class</label>
                                <select name="class" class="form-control" id="default" required="required">
                                    <option value="">Select Class</option>
                                    <?php
                                    $sql = "SELECT * from tblclasses";
                                    $query = $dbh->prepare($sql);
                                    $query->execute();
                                    $results = $query->fetchAll(PDO::FETCH_OBJ);
                                    if ($query->rowCount() > 0) {
                                        foreach ($results as $result) { ?>
                                            <option value="<?php echo htmlentities($result->id); ?>">
                                                <?php echo htmlentities($result->ClassName); ?> Section-<?php echo htmlentities($result->Section); ?>
                                            </option>
                                    <?php } } ?>
                                </select>
                            </div>

                            <div class="form-group mt-20 btn-inline-group">
                                <button type="submit" class="btn btn-success btn-labeled">
                                    Search <span class="btn-label btn-label-right"><i class="fa fa-check"></i></span>
                                </button>
                                <a href="index.php">Home</a>
                            </div>

                            <div class="clearfix"></div>
                        </form>

                        <hr>
                    </div>
                </div>
            </div>

            <!-- Footer outside the panel -->
            <div class="footer">
                © 2025 dynaclass
            </div>
        </div>
    </div>

    <!-- JS Dependencies -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <script src="js/jquery-ui/jquery-ui.min.js"></script>
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <script src="js/pace/pace.min.js"></script>
    <script src="js/lobipanel/lobipanel.min.js"></script>
    <script src="js/iscroll/iscroll.js"></script>
    <script src="js/icheck/icheck.min.js"></script>
    <script src="js/main.js"></script>

    <script>
        $(function () {
            $('input.flat-blue-style').iCheck({
                checkboxClass: 'icheckbox_flat-blue'
            });
        });
    </script>
</body>
</html>
