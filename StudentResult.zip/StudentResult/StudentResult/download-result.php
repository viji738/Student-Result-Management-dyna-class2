<?php
session_start();
require_once('includes/configpdo.php');
require_once('includes/fpdf.php');  // Make sure this path is correct

$rollid = $_SESSION['rollid'];
$classid = $_SESSION['classid'];

// Fetch student info (your existing code)
$query = "SELECT tblstudents.StudentName, tblstudents.RollId, tblclasses.ClassName, tblclasses.Section 
          FROM tblstudents 
          JOIN tblclasses ON tblclasses.id = tblstudents.ClassId 
          WHERE tblstudents.RollId = ? AND tblstudents.ClassId = ?";

$stmt = $mysqli->prepare($query);
$stmt->bind_param("ss", $rollid, $classid);
$stmt->execute();
$student = $stmt->get_result()->fetch_object();

$query = "SELECT s.SubjectName, r.marks 
          FROM tblresult r 
          JOIN tblstudents st ON r.StudentId = st.StudentId 
          JOIN tblsubjects s ON s.id = r.SubjectId 
          WHERE st.RollId = ? AND st.ClassId = ?";

$stmt = $mysqli->prepare($query);
$stmt->bind_param("ss", $rollid, $classid);
$stmt->execute();
$results = $stmt->get_result();

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Student Result', 0, 1, 'C');
$pdf->Ln(5);

$pdf->SetFont('Arial', '', 12);
$pdf->Cell(50, 10, 'Student Name: ' . $student->StudentName);
$pdf->Ln();
$pdf->Cell(50, 10, 'Roll ID: ' . $student->RollId);
$pdf->Ln();
$pdf->Cell(50, 10, 'Class: ' . $student->ClassName . ' (' . $student->Section . ')');
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(10, 10, '#', 1);
$pdf->Cell(100, 10, 'Subject', 1);
$pdf->Cell(30, 10, 'Marks', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 12);

$count = 1;
$totalMarks = 0;
while ($row = $results->fetch_assoc()) {
    $pdf->Cell(10, 10, $count, 1);
    $pdf->Cell(100, 10, $row['SubjectName'], 1);
    $pdf->Cell(30, 10, $row['marks'], 1);
    $pdf->Ln();
    $totalMarks += $row['marks'];
    $count++;
}

$outOf = ($count - 1) * 100;
$percentage = $outOf ? round(($totalMarks * 100) / $outOf, 2) : 0;

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(110, 10, 'Total Marks', 1);
$pdf->Cell(30, 10, $totalMarks . " / " . $outOf, 1);
$pdf->Ln();
$pdf->Cell(110, 10, 'Percentage', 1);
$pdf->Cell(30, 10, $percentage . '%', 1);

$pdf->Output('D', 'student_result.pdf');  // Force download PDF with this name
exit;
?>
