<?php
session_start();
error_reporting(0);
include('includes/config.php');

if (!empty($_SESSION['alogin'])) {
    unset($_SESSION['alogin']);
}

if (isset($_POST['login'])) {
    $uname = trim($_POST['username']);
    $password = $_POST['password'];
    $hashedPassword = md5($password);

    $sql = "SELECT UserName, Password FROM admin WHERE UserName = :uname AND Password = :password";
    $query = $dbh->prepare($sql);
    $query->bindParam(':uname', $uname, PDO::PARAM_STR);
    $query->bindParam(':password', $hashedPassword, PDO::PARAM_STR);
    $query->execute();

    if ($query->rowCount() > 0) {
        $_SESSION['alogin'] = $uname;
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Student Result Management System | Admin Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <!-- Fonts: Inter (main) and Dancing Script (calligraphic) -->
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <style>
    * {
      box-sizing: border-box;
    }
    body, html {
      margin: 0;
      height: 100%;
      font-family: 'Inter', sans-serif;
      background: url('images/Screenshot 2025-05-25 234359.png') no-repeat center center fixed;
      background-size: cover;
      position: relative;
      overflow: hidden;
    }

    body::before {
      content: "";
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(0,0,0,0.5);
      z-index: 0;
    }

    .container {
      position: relative;
      z-index: 1;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 1.5rem;
      gap: 1.8rem;
      max-width: 900px;
      margin: 0 auto;
      width: 90%;
    }

    h1.main-title {
      font-weight: 700;
      font-size: 3.8rem;
      color: #fff;
      text-shadow: 2px 2px 8px rgba(0,0,0,0.7);
      user-select: none;
      text-align: center;
      margin: 0;
      letter-spacing: 0.06em;
    }

    /* Calligraphic dynaclass */
 h2.sub-title {
  font-family: 'Dancing Script', cursive;
  font-size: 4rem;          /* Increased from 3rem to 4rem */
  color: #f9fafb;
  text-shadow: 2px 2px 10px rgba(0,0,0,0.6);
  margin: 0 0 2rem 0;
  user-select: none;
  text-align: center;
  font-weight: 900;         /* Increased font weight */
  letter-spacing: 0.05em;
}


    .form-wrapper {
      display: flex;
      gap: 3rem;
      justify-content: center;
      flex-wrap: wrap;
      width: 100%;
      max-width: 900px;
    }

    .card {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 12px;
  padding: 2rem 2.2rem;
  box-shadow: 0 12px 28px rgba(0,0,0,0.15);
  width: 380px; /* increased */
  transition: box-shadow 0.3s ease, transform 0.3s ease;
}

    .card:hover {
      box-shadow: 0 20px 40px rgba(0,0,0,0.2);
      transform: translateY(-6px);
    }

    .card h4 {
      font-weight: 600;
      font-size: 1.9rem;
      color: #111827;
      margin-bottom: 1rem;
      text-align: center;
      user-select: none;
    }

    .card p {
      font-size: 1.1rem;
      color: #4b5563;
      margin-bottom: 1.6rem;
      text-align: center;
      user-select: none;
    }

    .btn-primary,
    .btn-success {
      width: 100%;
      border-radius: 8px;
      font-weight: 700;
      padding: 0.75rem 0;
      font-size: 1.15rem;
      cursor: pointer;
      border: none;
      transition: background-color 0.25s ease;
      user-select: none;
      display: inline-block;
      text-align: center;
    }

    .btn-primary {
      background-color: #2563eb;
      color: #fff;
      text-decoration: none;
    }
    .btn-primary:hover,
    .btn-primary:focus {
      background-color: #1e40af;
      outline: none;
    }

    .btn-success {
      background-color: #10b981;
      color: #fff;
      border: none;
    }
    .btn-success:hover,
    .btn-success:focus {
      background-color: #059669;
      outline: none;
    }

    .form-group {
      margin-bottom: 1.2rem;
    }
    label {
      display: block;
      font-weight: 600;
      font-size: 1.1rem;
      margin-bottom: 0.5rem;
      color: #374151;
      user-select: none;
    }

    input.form-control {
      width: 100%;
      padding: 0.65rem 1rem;
      font-size: 1.1rem;
      border: 1.5px solid #d1d5db;
      border-radius: 8px;
      transition: border-color 0.3s ease;
    }
    input.form-control:focus {
      border-color: #2563eb;
      outline: none;
      box-shadow: 0 0 6px rgba(37, 99, 235, 0.5);
    }

    .alert {
      font-size: 1rem;
      color: #b91c1c;
      text-align: center;
      margin-top: 1rem;
      user-select: none;
    }

    @media (max-width: 768px) {
      .form-wrapper {
        flex-direction: column;
        align-items: center;
      }
      .card {
        width: 90%;
      }
    }
  </style>
</head>
<body>

  <div class="container" role="main">

    <h1 class="main-title">Student Result Management System</h1>
    <h2 class="sub-title">DynaClass</h2>

    <div class="form-wrapper">

      <section class="card" aria-label="Student results access">
        <h4>For Students</h4>
        <p>Quickly check your results here.</p>
        <a href="find-result.php" class="btn-primary" role="button" aria-label="View student results">View Results</a>
      </section>

      <section class="card" aria-label="Admin login form">
        <h4>Admin Login</h4>
        <form method="post" novalidate autocomplete="off" aria-describedby="error-message">
          <div class="form-group">
            <label for="username">Username</label>
            <input
              type="text"
              name="username"
              id="username"
              class="form-control"
              placeholder="Enter username"
              required
              autofocus
            />
          </div>

          <div class="form-group">
            <label for="password">Password</label>
            <input
              type="password"
              name="password"
              id="password"
              class="form-control"
              placeholder="Enter password"
              required
            />
          </div>

          <button type="submit" name="login" class="btn-success">Sign In</button>

          <?php if (isset($error)) : ?>
            <div class="alert" id="error-message" role="alert" aria-live="assertive">
              <?php echo htmlentities($error); ?>
            </div>
          <?php endif; ?>
        </form>
      </section>

    </div>
  </div>

</body>
</html>
